<?php require 'views/layouts/top.php' ?>
<?php require 'views/layouts/sidebar.php' ?>
<h1>Page not found.</h1>
<?php require 'views/layouts/bottom.php' ?>