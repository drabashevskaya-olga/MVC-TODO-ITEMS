<nav class="navbar navbar-expand-lg navbar-light bg-light">
  <ul class="navbar-nav mr-auto">
    <li class="nav-item">
      <a class="nav-link" href="/">
        Home
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-item nav-link" href="/add">
        Add new task
      </a>
    </li>
    <li class="nav-item">
      <a class="nav-item nav-link" href="/login">
        Login
      </a>
    </li>
  </ul>
</nav>