<?php

namespace App\Models;

class UserModel
{
    protected $id;
    protected $login;
    protected $password;
    protected $table = "users";
}