<?php

return [
    'database' => [
        'dbname' => 'u1813409_todo_list',
        'username' => 'u1813409_default',
        'password' => 'd5hD475VcjOMh8kW',
        'driver' => 'mysql',
        'host' => 'localhost',
        'options' => [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ],
    ],
    'DEBUG' => true
];